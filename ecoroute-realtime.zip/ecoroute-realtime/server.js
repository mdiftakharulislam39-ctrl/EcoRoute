const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const path = require("path");

const app = express();
const server = http.createServer(app);
const io = new Server(server);

const PORT = 3000;

app.use(express.static(path.join(__dirname, "public")));

app.get("/", (req, res) => {
  res.send(`
    <!DOCTYPE html>
    <html>
    <head>
      <title>EcoRoute Campus Shuttle Tracking System</title>

      <style>
        * {
          box-sizing: border-box;
        }

        body {
          margin: 0;
          font-family: Arial, sans-serif;
          min-height: 100vh;
          background:
            radial-gradient(circle at top left, rgba(34,197,94,0.35), transparent 35%),
            radial-gradient(circle at bottom right, rgba(59,130,246,0.35), transparent 40%),
            linear-gradient(135deg, #020617, #0f172a, #111827);
          color: white;
          padding: 35px;
        }

        .page {
          max-width: 1200px;
          margin: auto;
        }

        .nav {
          display: flex;
          align-items: center;
          justify-content: space-between;
          margin-bottom: 35px;
        }

        .brand {
          display: flex;
          align-items: center;
          gap: 14px;
        }

        .logo {
          width: 58px;
          height: 58px;
          border-radius: 18px;
          background: linear-gradient(135deg, #22c55e, #38bdf8);
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 30px;
          box-shadow: 0 18px 45px rgba(34,197,94,0.25);
        }

        .brand h2 {
          margin: 0;
          font-size: 28px;
        }

        .brand p {
          margin: 4px 0 0;
          color: #94a3b8;
        }

        .status {
          display: inline-flex;
          align-items: center;
          gap: 10px;
          background: rgba(34,197,94,0.16);
          border: 1px solid rgba(34,197,94,0.45);
          color: #bbf7d0;
          padding: 11px 18px;
          border-radius: 999px;
          font-weight: bold;
        }

        .dot {
          width: 10px;
          height: 10px;
          background: #22c55e;
          border-radius: 50%;
          box-shadow: 0 0 0 8px rgba(34,197,94,0.15);
        }

        .hero {
          display: grid;
          grid-template-columns: 1.15fr 0.85fr;
          gap: 28px;
          align-items: stretch;
        }

        .hero-card {
          background: rgba(15,23,42,0.88);
          border: 1px solid rgba(148,163,184,0.25);
          border-radius: 30px;
          padding: 45px;
          box-shadow: 0 25px 80px rgba(0,0,0,0.35);
          overflow: hidden;
          position: relative;
        }

        .hero-card::after {
          content: "";
          width: 280px;
          height: 280px;
          background: radial-gradient(circle, rgba(56,189,248,0.35), transparent 65%);
          position: absolute;
          right: -90px;
          top: -80px;
        }

        .badge {
          display: inline-flex;
          gap: 9px;
          align-items: center;
          padding: 9px 15px;
          border-radius: 999px;
          background: rgba(59,130,246,0.18);
          border: 1px solid rgba(96,165,250,0.45);
          color: #bfdbfe;
          font-weight: bold;
          margin-bottom: 24px;
          position: relative;
          z-index: 1;
        }

        h1 {
          position: relative;
          z-index: 1;
          margin: 0 0 20px;
          font-size: 58px;
          line-height: 1.05;
          letter-spacing: -1.5px;
        }

        .gradient-text {
          background: linear-gradient(135deg, #38bdf8, #22c55e);
          -webkit-background-clip: text;
          color: transparent;
        }

        .description {
          position: relative;
          z-index: 1;
          color: #cbd5e1;
          font-size: 18px;
          line-height: 1.8;
          max-width: 780px;
          margin-bottom: 30px;
        }

        .actions {
          position: relative;
          z-index: 1;
          display: flex;
          flex-wrap: wrap;
          gap: 15px;
        }

        .btn {
          text-decoration: none;
          color: white;
          padding: 16px 22px;
          border-radius: 16px;
          font-weight: bold;
          transition: 0.25s;
          display: inline-flex;
          align-items: center;
          gap: 10px;
        }

        .btn:hover {
          transform: translateY(-4px);
        }

        .btn-driver {
          background: linear-gradient(135deg, #2563eb, #06b6d4);
          box-shadow: 0 15px 40px rgba(37,99,235,0.25);
        }

        .btn-student {
          background: linear-gradient(135deg, #16a34a, #22c55e);
          box-shadow: 0 15px 40px rgba(22,163,74,0.25);
        }

        .side-panel {
          background: rgba(15,23,42,0.88);
          border: 1px solid rgba(148,163,184,0.25);
          border-radius: 30px;
          padding: 32px;
          box-shadow: 0 25px 80px rgba(0,0,0,0.28);
        }

        .side-panel h2 {
          margin: 0 0 20px;
          font-size: 28px;
        }

        .feature {
          background: rgba(255,255,255,0.08);
          border: 1px solid rgba(255,255,255,0.1);
          border-radius: 22px;
          padding: 20px;
          margin-bottom: 16px;
        }

        .feature h3 {
          margin: 0 0 8px;
          font-size: 19px;
        }

        .feature p {
          margin: 0;
          color: #94a3b8;
          line-height: 1.6;
          font-size: 14px;
        }

        .stats {
          margin-top: 28px;
          display: grid;
          grid-template-columns: repeat(4, 1fr);
          gap: 18px;
        }

        .stat-card {
          background: rgba(15,23,42,0.88);
          border: 1px solid rgba(148,163,184,0.22);
          border-radius: 24px;
          padding: 24px;
        }

        .stat-card small {
          color: #94a3b8;
        }

        .stat-card strong {
          display: block;
          margin-top: 10px;
          font-size: 26px;
        }

        .footer {
          margin-top: 28px;
          color: #94a3b8;
          text-align: center;
          font-size: 14px;
        }

        @media (max-width: 950px) {
          .hero {
            grid-template-columns: 1fr;
          }

          .stats {
            grid-template-columns: repeat(2, 1fr);
          }

          h1 {
            font-size: 42px;
          }

          .nav {
            flex-direction: column;
            align-items: flex-start;
            gap: 18px;
          }
        }

        @media (max-width: 550px) {
          body {
            padding: 18px;
          }

          .hero-card,
          .side-panel {
            padding: 26px;
          }

          .stats {
            grid-template-columns: 1fr;
          }

          h1 {
            font-size: 34px;
          }
        }
      </style>
    </head>

    <body>
      <div class="page">
        <div class="nav">
          <div class="brand">
            <div class="logo">🚐</div>
            <div>
              <h2>EcoRoute</h2>
              <p>Campus Shuttle Optimization System</p>
            </div>
          </div>

          <div class="status">
            <span class="dot"></span>
            Real-Time Demo Online
          </div>
        </div>

        <section class="hero">
          <div class="hero-card">
            <div class="badge">⚡ Node.js + Socket.IO Live Implementation</div>

            <h1>
              Smart Campus Shuttle <br>
              <span class="gradient-text">Tracking System</span>
            </h1>

            <p class="description">
              EcoRoute is a real-time campus transportation platform where drivers send live
              shuttle movement data and students track shuttle position, speed, ETA, and route
              updates through a modern map-based dashboard.
            </p>

            <div class="actions">
              <a class="btn btn-driver" href="/driver.html" target="_blank">
                🚐 Open Driver Module
              </a>

              <a class="btn btn-student" href="/student.html" target="_blank">
                🗺️ Open Student Tracking
              </a>
            </div>
          </div>

          <div class="side-panel">
            <h2>Project Modules</h2>

            <div class="feature">
              <h3>🚐 Driver Module</h3>
              <p>
                Sends shuttle latitude, longitude, speed, route name, and timestamp
                to the backend server in real time.
              </p>
            </div>

            <div class="feature">
              <h3>🗺️ Student Tracking Dashboard</h3>
              <p>
                Displays live shuttle marker, route line, ETA, speed, and current
                shuttle status on an interactive map.
              </p>
            </div>

            <div class="feature">
              <h3>⚙️ Backend Server</h3>
              <p>
                Receives driver data and broadcasts location updates instantly using
                Socket.IO real-time communication.
              </p>
            </div>
          </div>
        </section>

        <section class="stats">
          <div class="stat-card">
            <small>Core Feature</small>
            <strong>Live Tracking</strong>
          </div>

          <div class="stat-card">
            <small>Backend</small>
            <strong>Node.js</strong>
          </div>

          <div class="stat-card">
            <small>Real-Time Layer</small>
            <strong>Socket.IO</strong>
          </div>

          <div class="stat-card">
            <small>Map View</small>
            <strong>Leaflet</strong>
          </div>
        </section>

        <div class="footer">
          EcoRoute Real-Time MVP Demo | Software Project Planning Assignment
        </div>
      </div>
    </body>
    </html>
  `);
});

let latestLocation = null;

io.on("connection", (socket) => {
  console.log("User connected:", socket.id);

  if (latestLocation) {
    socket.emit("receive-location", latestLocation);
  }

  socket.on("send-location", (data) => {
    latestLocation = {
      shuttleId: data.shuttleId || "SH-01",
      driverId: data.driverId || "D-01",
      routeName: data.routeName || "Main Gate → CSE Building",
      latitude: data.latitude,
      longitude: data.longitude,
      speed: data.speed || 0,
      updatedAt: new Date().toLocaleTimeString()
    };

    console.log("Location received:", latestLocation);

    io.emit("receive-location", latestLocation);
  });

  socket.on("disconnect", () => {
    console.log("User disconnected:", socket.id);
  });
});

server.listen(PORT, () => {
  console.log(`EcoRoute server running at http://localhost:${PORT}`);
});



